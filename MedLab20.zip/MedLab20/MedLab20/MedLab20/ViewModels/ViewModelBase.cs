﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace MedLab20.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}