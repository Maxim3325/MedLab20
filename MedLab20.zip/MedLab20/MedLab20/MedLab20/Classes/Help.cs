using Avalonia.Controls;

namespace MedLab20.Classes;

public class Help
{
    public static ContentControl MainCC;
}