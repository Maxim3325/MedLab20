using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace MedLab20.Views;

public partial class Buhgalter : UserControl
{
    public Buhgalter()
    {
        InitializeComponent();
    }
}