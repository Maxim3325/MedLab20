using Avalonia.Controls;
using Avalonia.Interactivity;
using MedLab20.Classes;

namespace MedLab20.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        MainCC.Content = new AutoPage();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        MainCC.Content = new AutoPage();
    }
}