using Avalonia.Controls;

namespace MedLab20.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}