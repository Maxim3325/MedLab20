using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using MedLab20.Classes;

namespace MedLab20.Views;

public partial class AutoPage : UserControl
{
    public AutoPage()
    {
        InitializeComponent();
        
    }


    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        if(LoginTb.Text == "admin" && PasswordTb.Text == "admin")
        {
            Help.MainCC.Content = new AdminPage();
        }
        
        if(LoginTb.Text == "laborant" && PasswordTb.Text == "laborant")
        {
            Help.MainCC.Content = new LaborantPage();
        }
        
        if(LoginTb.Text == "isledovatel" && PasswordTb.Text == "isledovatel")
        {
            Help.MainCC.Content = new LaborantIsledovatel();
        }
    }

    private void PasswordChar_OnClick(object? sender, RoutedEventArgs e)
    {
        if (PasswordTb.PasswordChar == '\0')
        {
            PasswordTb.PasswordChar = '*';
        }
        else
        {
            PasswordTb.PasswordChar = '\0';
        }
    }
}