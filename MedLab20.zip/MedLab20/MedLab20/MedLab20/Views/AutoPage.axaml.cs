using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using MedLab20.Classes;

namespace MedLab20.Views;

public partial class AutoPage : UserControl
{
    public AutoPage()
    {
        InitializeComponent();
        
    }


    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        if(LoginTb.Text == "Admin" && PasswordTb.Text == "Admin")
        {
            Help.MainCC.Content = new AdminPage();
        }
    }
}